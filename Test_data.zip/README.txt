1. Polycrystalline_Al_DP.txt 		- polycrystalline diffraction pattern

This is NOT the calibration standard used for the amorphous SiO2 diffraction data below.


2. Amorphous_SiO2_DP_0.00167.txt 	- amorphous 18nm SiO2 film
					- Difraction pattern recorded with a centred direct beam
					- use 0.00167 as value for calibration factor


3. Amorphous_SiO2_azav_0.00167.txt 	- Amorphous 18nm SiO2 film
					- Azimuthally averaged intensity profile 
					- from diffraction pattern recorded with an off-centred direct beam
					- use 0.00167 as value for calibration factor